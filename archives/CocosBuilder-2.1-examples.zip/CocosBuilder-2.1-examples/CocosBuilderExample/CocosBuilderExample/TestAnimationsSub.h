//
//  TestAnimationsSub.h
//  CocosBuilderExample
//
//  Created by Viktor Lidholt on 8/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CCLayer.h"

@interface TestAnimationsSub : CCLayer

@end
