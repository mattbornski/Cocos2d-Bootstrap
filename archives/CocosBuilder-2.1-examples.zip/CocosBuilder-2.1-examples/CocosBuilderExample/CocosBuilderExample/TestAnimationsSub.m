//
//  TestAnimationsSub.m
//  CocosBuilderExample
//
//  Created by Viktor Lidholt on 8/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TestAnimationsSub.h"

@implementation TestAnimationsSub

@end
